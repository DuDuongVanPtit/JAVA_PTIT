package TH3.Bai4;
public class School {
    private String code, name;
    public School(String code, String name) {
        this.code = code;
        this.name = name;
        
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }
    
}
